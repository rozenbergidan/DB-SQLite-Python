from ApplicationLayer.Session import Session


if __name__ == '__main__':
        ses = Session()
        ses.run()

