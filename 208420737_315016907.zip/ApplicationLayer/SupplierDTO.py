class SupplierDTO:
    def __init__(self, idd, name, logistic):
        self.id = idd
        self.name = name
        self.logistic = logistic
