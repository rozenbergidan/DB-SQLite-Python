
class ClinicDTO:
    def __init__(self, idd, location, demand, logistic):
        self.id = idd
        self.location = location
        self.demand = demand
        self.logistic = logistic
