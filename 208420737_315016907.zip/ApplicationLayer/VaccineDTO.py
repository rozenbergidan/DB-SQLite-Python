class VaccineDTO:
    def __init__(self, idd, date, supplier, quantity):
        self.id = idd
        self.date = date
        self.supplier = supplier
        self.quantity = quantity
