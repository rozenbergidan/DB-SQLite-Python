
class LogisticDTO:
    def __init__(self,idd, name, count_sent, count_received):
        self.id = idd
        self.name = name
        self.count_sent = count_sent
        self.count_received = count_received
